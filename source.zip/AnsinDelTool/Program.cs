﻿
using System.Diagnostics;
using System.IO;
using System.Net;

class Program
{
    static void Main(string[] args)
    {
        EnsureAdmin();
        string adbPath = Environment.GetEnvironmentVariable("ADB_PATH") ?? "";
        if (string.IsNullOrEmpty(adbPath) || !File.Exists(Path.Combine(adbPath, "adb.exe")))
        {
            DownloadAndSetupADB();
        }

        Console.WriteLine("どのキャリアを使用していますか？");
        Console.WriteLine("1. Docomo");
        Console.WriteLine("2. au");
        Console.WriteLine("3. SoftBank");
        Console.Write("番号を選択してください（1/2/3）: ");
        string carrier = Console.ReadLine();

        switch (carrier)
        {
            case "1":
                Console.WriteLine("Docomo を選択しました。");
                DisableFilter("jp.co.nttdocomo.anshinmode");
                break;
            case "2":
                Console.WriteLine("au を選択しました。");
                DisableFilter("jp.netstar.familysmile");
                break;
            case "3":
                Console.WriteLine("SoftBank を選択しました。");
                DisableFilter("jp.softbank.mb.parentalcontrols");
                break;
            default:
                Console.WriteLine("無効な選択です。");
                break;
        }

        Cleanup();
    }

    static void EnsureAdmin()
    {
        var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
        var principal = new System.Security.Principal.WindowsPrincipal(identity);
        bool isAdmin = principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);

        if (!isAdmin)
        {
            Console.WriteLine("管理者権限が必要です。このプログラムを管理者として再実行します。");
            ProcessStartInfo procInfo = new ProcessStartInfo
            {
                UseShellExecute = true,
                WorkingDirectory = Environment.CurrentDirectory,
                FileName = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName,
                Verb = "runas"
            };
            try
            {
                Process.Start(procInfo);
            }
            catch
            {
                Console.WriteLine("管理者権限で再実行できませんでした。");
            }
            Environment.Exit(0);
        }
    }

    static void DownloadAndSetupADB()
    {
        string url = "https://github.com/ajt2000000/AnsinCrack/raw/main/adb.zip";
        string zipPath = "adb.zip";

        Console.WriteLine("Downloading ADB...");
        using (WebClient client = new WebClient())
        {
            client.DownloadFile(url, zipPath);
        }

        Console.WriteLine("Download successful.");
        System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, Directory.GetCurrentDirectory());
        File.Delete(zipPath);

        string adbPath = Path.Combine(Directory.GetCurrentDirectory(), "platform-tools");
        string envPath = Environment.GetEnvironmentVariable("PATH");
        envPath += ";" + adbPath;
        Environment.SetEnvironmentVariable("PATH", envPath);
        Console.WriteLine("ADB installed and added to PATH.");
    }

    static void DisableFilter(string packageName)
    {
        ExecuteCommand("adb shell svc wifi disable");
        ExecuteCommand("adb shell svc data disable");
        Console.WriteLine("Wifiやモバイルデータ通信などを切ってください。ENTERを押してください。");
        Console.ReadLine();
        ExecuteCommand($"adb shell am force-stop {packageName}");
        Console.WriteLine("あんしんフィルターの停止完了です。この後無効化処理を行います。ENTERを押してください。");
        Console.ReadLine();
        ExecuteCommand($"adb shell pm disable-user --user 0 {packageName}");
        Console.WriteLine("あんしんフィルターを無効化しました。デバイスを3秒後に再起動します。");
        ExecuteCommand("adb shell svc data enable");
        ExecuteCommand("adb shell svc wifi enable");
        System.Threading.Thread.Sleep(3000);
        ExecuteCommand("adb reboot");
        Console.WriteLine("作業が完了しました。再起動後にWi-Fi・モバイルデータを有効化してください。");
    }

    static void ExecuteCommand(string command)
    {
        ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + command)
        {
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        Process proc = new Process
        {
            StartInfo = procStartInfo
        };
        proc.Start();
        proc.WaitForExit();
    }

    static void Cleanup()
    {
        string exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
        Console.WriteLine("この実行ファイルを削除します...");
        ProcessStartInfo procInfo = new ProcessStartInfo
        {
            Arguments = $"/C choice /C Y /N /D Y /T 3 & Del {exePath}",
            WindowStyle = ProcessWindowStyle.Hidden,
            CreateNoWindow = true,
            FileName = "cmd.exe"
        };
        Process.Start(procInfo);
    }
}

